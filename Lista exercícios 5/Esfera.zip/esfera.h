typedef struct esfera tipo_esfera;

tipo_esfera *cria_esfera (float);
float raio_esfera (tipo_esfera*);
float area_esfera (tipo_esfera*);
float volume_esfera (tipo_esfera*);
 