
typedef struct racional tipo_racional;

tipo_racional *cria_racional (int,int);
tipo_racional *soma_racional (tipo_racional *, tipo_racional *);
tipo_racional *multiplica_racional (tipo_racional *, tipo_racional *);
int racionaiscmp (tipo_racional *, tipo_racional *);