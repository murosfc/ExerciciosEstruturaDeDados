#include <stdio.h>
#include "racionais.h"

struct racional
{
	int dividendo;
	int divisor;
};

typedef struct racional tipo_racional;

int main()
{
	int dividendo,divisor;
	tipo_racional *racional1,*racional2,*temp;
	printf ("\nDigite o dividendo do primeiro racional: ");
	scanf ("%d",&dividendo);
	printf ("\nDigite o divisor do primeiro racional: ");
	scanf ("%d",&divisor);
	racional1=cria_racional(dividendo,divisor);
	printf ("\nRacional 1: %d/%d\n",racional1->dividendo,racional1->divisor);
	printf ("\nDigite o dividendo do segundo racional: ");
	scanf ("%d",&dividendo);
	printf ("\nDigite o divisor do segundo racional: ");
	scanf ("%d",&divisor);
	racional2=cria_racional(dividendo,divisor);
	printf ("\nRacional 1: %d/%d\n",racional2->dividendo,racional2->divisor);
	temp=soma_racional(racional1,racional2);
	printf ("\nSoma das fracoes: %d/%d\n",temp->dividendo,temp->divisor);
	temp=multiplica_racional(racional1,racional2);
	printf ("\nMultiplicacao das fracoes: %d/%d\n",temp->dividendo,temp->divisor);
	if (racionaiscmp(racional1,racional2)==1)
		printf ("\nAs fracoes sao iguais\n");
	else printf ("\nAs fracoes sao diferentes\n");
	return 0;
}