
typedef struct pilha tipo_pilha;

tipo_pilha *criaPilha();

void push (tipo_pilha* , char);

char pop (tipo_pilha*);

int tamanhoPilha (tipo_pilha *);

int checaParenteses (tipo_pilha *);